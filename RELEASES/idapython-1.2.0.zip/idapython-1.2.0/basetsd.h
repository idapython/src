#ifndef _BASETSD_H
#define _BASETSD_H
/* Microsoft free compilers seem to lack this file and Python needs it */ 
#endif
